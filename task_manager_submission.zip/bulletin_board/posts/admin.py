django.contrib 

import admin

posts/admin.py from django.contrib 

import admin from .models 

import Post from .models 

import Author 

Author model admin.site.register(Author)

Post model admin.site.register(Post) 


