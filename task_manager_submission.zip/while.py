total = 0
count = 0
while True:
    num = input("Enter a number (enter -1 to stop): ")
    if num == '-1':
       break
    if not num.lstrip('-').isdigit():
        print("Invalid input! Please enter a real number.")
        continue
    num = float(num)

    count += 1
    total += num

if count > 0:
    
    average = total / count
    print(f"The average of the numbers entered is: {average}")
else:
    print("No numbers entered.")
    