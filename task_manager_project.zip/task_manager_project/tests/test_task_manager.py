import unittest
from models.user import User
from models.task import Task


class TestUserAuthentication(unittest.TestCase):
    """Tests user authentication."""

    def setUp(self) -> None:
        self.user = User("alice", "SecurePass123")

    def test_successful_authentication(self) -> None:
        self.assertTrue(self.user.authenticate("SecurePass123"))

    def test_failed_authentication(self) -> None:
        self.assertFalse(self.user.authenticate("WrongPass"))


class TestTaskCreation(unittest.TestCase):
    """Tests task creation."""

    def setUp(self) -> None:
        self.task = Task(
            username="bob",
            title="Submit Report",
            description="Quarterly summary",
            assigned_date="20 Sep 2026",
            due_date="25 Sep 2026",
            task_id=1,
        )

    def test_task_initial_state(self) -> None:
        self.assertFalse(self.task.completed)
        self.assertEqual(self.task.completed_str, "No")
        self.assertEqual(self.task.username, "bob")

    def test_task_serialization_format(self) -> None:
        expected_str = (
            "bob, Submit Report, Quarterly summary, "
            "20 Sep 2026, 25 Sep 2026, No\n"
        )
        self.assertEqual(
            self.task.to_file_format(), expected_str
        )


class TestMarkTaskComplete(unittest.TestCase):
    """Tests marking task complete."""

    def setUp(self) -> None:
        self.task = Task(
            username="charlie",
            title="Write Code",
            description="Implement tests",
            assigned_date="20 Sep 2026",
            due_date="30 Sep 2026",
        )

    def test_mark_complete(self) -> None:
        self.assertFalse(self.task.completed)
        self.task.mark_complete()
        self.assertTrue(self.task.completed)


if __name__ == "__main__":
    unittest.main()
