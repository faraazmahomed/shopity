from django.urls import path
from . import views

urlpatterns = [
    path("authors/", views.authors_view, name="authors"),
]