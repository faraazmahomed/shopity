from django.contrib import admin
from django.urls import include, path
from django.shortcuts import render
from .models import Author

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("posts.urls")),
]


def authors_view(request):
    authors = Author.objects.all()
    return render(request, "posts/authors.html", {"authors": authors})
