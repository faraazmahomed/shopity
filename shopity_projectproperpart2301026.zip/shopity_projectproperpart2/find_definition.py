import os
from pathlib import Path

def scan_for_definition():
    project_root = Path.cwd()
    print(f"Scanning directory: {project_root}\n")
    
    matches_found = 0
    for py_file in project_root.glob("**/*.py"):
        if ".venv" in py_file.parts or "venv" in py_file.parts or "__pycache__" in py_file.parts:
            continue
            
        try:
            with open(py_file, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    # Look for function or class definitions of store_context
                    if "def store_context" in line or "class store_context" in line:
                        matches_found += 1
                        print(f"✅ Found Definition in: {py_file.relative_to(project_root)}")
                        print(f"   Line {line_num}: {line.strip()}\n")
        except Exception as e:
            pass
            
    if matches_found == 0:
        print("No explicit definition of 'store_context' found using 'def' or 'class'. It might be assigned as a variable or imported from elsewhere.")

if __name__ == "__main__":
    scan_for_definition()
